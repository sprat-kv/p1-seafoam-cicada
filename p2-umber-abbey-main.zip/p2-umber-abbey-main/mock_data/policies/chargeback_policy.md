# Chargeback Policy

Duplicate charges are refunded after verification.
