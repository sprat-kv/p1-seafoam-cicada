# Delivery Policy

Standard deliveries: 3–5 business days.
If delayed beyond 7 days, refund or replacement may be offered.
